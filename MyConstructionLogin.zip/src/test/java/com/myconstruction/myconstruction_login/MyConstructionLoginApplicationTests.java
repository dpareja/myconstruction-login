package com.myconstruction.myconstruction_login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyConstructionLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
